#!/usr/bin/env bash
# --------------------------------------------------------------------------------------------------------------------
# Modified from https://github.com/chengdazhi/Deformable-Convolution-V2-PyTorch/tree/pytorch_1.0.0 and Deformable DETR
# --------------------------------------------------------------------------------------------------------------------

python setup.py build install
